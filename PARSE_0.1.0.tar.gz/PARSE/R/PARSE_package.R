#' @title Model-based clustering with Penalty Functions
#'
#' @description The package \pkg{PARSE} provides functions for the model-based clustering with multiple penalty functions including APL1, APFP and PARSE.

#' @docType package
#' @name PARSE
NULL
